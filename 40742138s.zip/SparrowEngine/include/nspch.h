#pragma once

#include "NS/core/PlatformDetection.h"

#include "NS/core/Log.h"