#pragma once

#include "../Base.h"

namespace ns {

	class NS_API MasterAudio {
	public:

		static void Init();

		static void SetPosition(float x, float y, float z);

	};

}
