#version 330

layout (location = 0) out vec4 out_Color;

void main() {

	out_Color = vec4(1.0);

}