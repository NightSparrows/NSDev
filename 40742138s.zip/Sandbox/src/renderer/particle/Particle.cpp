
#include "Particle.h"

bool Particle::update(float delta) {
	this->m_velocity += (-90.f)/* Gravity */ * this->gravityEffect * delta;

	return true;
}
