#pragma once

#include <NS/SparrowEngine.h>

class Particle {
public:

protected:
	bool update(float delta);

private:
	glm::vec3 m_position;
	glm::vec3 m_velocity;
	float gravityEffect;
	float lifeLength;
	float rotation;
	float scale;

	float elapsedTime;
};
